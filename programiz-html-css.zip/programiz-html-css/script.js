function greet() {
    alert("Hello, welcome to my GitHub repository!");
}